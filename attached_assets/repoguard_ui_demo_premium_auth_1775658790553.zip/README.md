# RepoGuard Premium Demo + Settings + Auth

## Backend
```bash
cd backend
pip install -r requirements.txt
python run.py
```

## Frontend
```bash
cd frontend
npm install
npm run dev
```

## Included
- Email login screen
- 2FA demo verification flow
- Settings modal
- Sound on/off
- Haptics on/off
- Light/dark mode
- Animated four-stage RepoGuard demo
- Live event feed
- Compliance score and repo status board

## Important
This package includes a demo-grade email + 2FA flow for presentation. It is not a production identity system.
